import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './components/ThemeProvider';

import SplashScreen from './screens/SplashScreen';
import Onboarding1 from './screens/Onboarding1';
import Onboarding2 from './screens/Onboarding2';
import Onboarding3 from './screens/Onboarding3';
import SignUp from './screens/SignUp';
import Login from './screens/Login';
import ForgotPassword from './screens/ForgotPassword';
import OTPVerification from './screens/OTPVerification';
import CreateProfile from './screens/CreateProfile';
import SelectPreferences from './screens/SelectPreferences';
import HomeDashboard from './screens/HomeDashboard';
import AIChatAssistant from './screens/AIChatAssistant';
import AIPromptSuggestions from './screens/AIPromptSuggestions';
import CreateNewTrip from './screens/CreateNewTrip';
import DestinationSearch from './screens/DestinationSearch';
import DestinationDetails from './screens/DestinationDetails';
import PopularDestinations from './screens/PopularDestinations';
import AIItineraryGenerator from './screens/AIItineraryGenerator';
import GeneratedItineraryOverview from './screens/GeneratedItineraryOverview';
import DayWiseTripPlan from './screens/DayWiseTripPlan';
import InteractiveMapView from './screens/InteractiveMapView';
import HotelRecommendations from './screens/HotelRecommendations';
import HotelDetails from './screens/HotelDetails';
import FlightSearch from './screens/FlightSearch';
import FlightDetails from './screens/FlightDetails';
import BudgetPlanner from './screens/BudgetPlanner';
import ExpenseTracker from './screens/ExpenseTracker';
import CurrencyConverter from './screens/CurrencyConverter';
import WeatherForecast from './screens/WeatherForecast';
import LocalEventsDiscovery from './screens/LocalEventsDiscovery';
import RestaurantRecommendations from './screens/RestaurantRecommendations';
import ActivityBooking from './screens/ActivityBooking';
import SmartPackingChecklist from './screens/SmartPackingChecklist';
import LanguageTranslator from './screens/LanguageTranslator';
import EmergencyContacts from './screens/EmergencyContacts';
import TravelInsurance from './screens/TravelInsurance';
import GroupTripCollaboration from './screens/GroupTripCollaboration';
import ChatWithTravelGroup from './screens/ChatWithTravelGroup';
import AITravelInsights from './screens/AITravelInsights';
import SavedTrips from './screens/SavedTrips';
import WishlistScreen from './screens/WishlistScreen';
import NotificationsCenter from './screens/NotificationsCenter';
import UserProfile from './screens/UserProfile';
import SettingsScreen from './screens/SettingsScreen';
import SubscriptionPlans from './screens/SubscriptionPlans';
import PaymentGateway from './screens/PaymentGateway';
import BookingConfirmation from './screens/BookingConfirmation';
import ReviewsAndRatings from './screens/ReviewsAndRatings';
import HelpAndSupport from './screens/HelpAndSupport';
import SuccessCelebration from './screens/SuccessCelebration';

export default function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="trip-planner-theme">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SplashScreen />} />
          <Route path="/onboarding-1" element={<Onboarding1 />} />
          <Route path="/onboarding-2" element={<Onboarding2 />} />
          <Route path="/onboarding-3" element={<Onboarding3 />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/otp" element={<OTPVerification />} />
          <Route path="/create-profile" element={<CreateProfile />} />
          <Route path="/preferences" element={<SelectPreferences />} />
          <Route path="/home" element={<HomeDashboard />} />
          <Route path="/ai-chat" element={<AIChatAssistant />} />
          <Route path="/ai-prompts" element={<AIPromptSuggestions />} />
          <Route path="/create-trip" element={<CreateNewTrip />} />
          <Route path="/search" element={<DestinationSearch />} />
          <Route path="/destination/:id" element={<DestinationDetails />} />
          <Route path="/popular" element={<PopularDestinations />} />
          <Route path="/generate-itinerary" element={<AIItineraryGenerator />} />
          <Route path="/itinerary/:id" element={<GeneratedItineraryOverview />} />
          <Route path="/itinerary/:id/day/:day" element={<DayWiseTripPlan />} />
          <Route path="/map" element={<InteractiveMapView />} />
          <Route path="/hotels" element={<HotelRecommendations />} />
          <Route path="/hotel/:id" element={<HotelDetails />} />
          <Route path="/flights" element={<FlightSearch />} />
          <Route path="/flight/:id" element={<FlightDetails />} />
          <Route path="/budget" element={<BudgetPlanner />} />
          <Route path="/expenses" element={<ExpenseTracker />} />
          <Route path="/currency" element={<CurrencyConverter />} />
          <Route path="/weather" element={<WeatherForecast />} />
          <Route path="/events" element={<LocalEventsDiscovery />} />
          <Route path="/restaurants" element={<RestaurantRecommendations />} />
          <Route path="/activities" element={<ActivityBooking />} />
          <Route path="/packing" element={<SmartPackingChecklist />} />
          <Route path="/translate" element={<LanguageTranslator />} />
          <Route path="/emergency" element={<EmergencyContacts />} />
          <Route path="/insurance" element={<TravelInsurance />} />
          <Route path="/group/:id" element={<GroupTripCollaboration />} />
          <Route path="/group/:id/chat" element={<ChatWithTravelGroup />} />
          <Route path="/insights" element={<AITravelInsights />} />
          <Route path="/saved-trips" element={<SavedTrips />} />
          <Route path="/wishlist" element={<WishlistScreen />} />
          <Route path="/notifications" element={<NotificationsCenter />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/settings" element={<SettingsScreen />} />
          <Route path="/subscription" element={<SubscriptionPlans />} />
          <Route path="/payment" element={<PaymentGateway />} />
          <Route path="/confirmation" element={<BookingConfirmation />} />
          <Route path="/reviews" element={<ReviewsAndRatings />} />
          <Route path="/support" element={<HelpAndSupport />} />
          <Route path="/success" element={<SuccessCelebration />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
