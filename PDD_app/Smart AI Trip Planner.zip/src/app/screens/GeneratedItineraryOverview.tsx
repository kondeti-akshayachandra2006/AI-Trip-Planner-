import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Calendar, MapPin, DollarSign, Share2, Download, Edit } from 'lucide-react';
import Button from '../components/Button';
import GlassCard from '../components/GlassCard';

const days = [
  { day: 1, title: 'Arrival & Eiffel Tower', activities: 3, image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400' },
  { day: 2, title: 'Louvre & Seine Cruise', activities: 4, image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=400' },
  { day: 3, title: 'Versailles Palace', activities: 2, image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400' },
  { day: 4, title: 'Montmartre & Art Scene', activities: 5, image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400' },
];

export default function GeneratedItineraryOverview() {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <div className="min-h-screen w-full bg-background pb-24">
      <div className="bg-gradient-to-r from-primary to-secondary p-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate(-1)} className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-white font-bold">Paris Itinerary</h1>
              <p className="text-white/80 text-sm">4 Days</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <Share2 className="w-5 h-5 text-white" />
            </button>
            <button className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <Download className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <GlassCard className="bg-white/20 border-white/30 text-center">
            <Calendar className="w-5 h-5 text-white mx-auto mb-1" />
            <p className="text-white text-sm">4 Days</p>
          </GlassCard>
          <GlassCard className="bg-white/20 border-white/30 text-center">
            <MapPin className="w-5 h-5 text-white mx-auto mb-1" />
            <p className="text-white text-sm">12 Places</p>
          </GlassCard>
          <GlassCard className="bg-white/20 border-white/30 text-center">
            <DollarSign className="w-5 h-5 text-white mx-auto mb-1" />
            <p className="text-white text-sm">$2,400</p>
          </GlassCard>
        </div>
      </div>

      <div className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold">Day-by-Day Plan</h2>
          <button className="text-primary text-sm flex items-center gap-1">
            <Edit className="w-4 h-4" />
            Customize
          </button>
        </div>

        {days.map((day) => (
          <GlassCard
            key={day.day}
            onClick={() => navigate(`/itinerary/${id}/day/${day.day}`)}
            className="cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0">
                <img src={day.image} alt={day.title} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-primary font-medium mb-1">Day {day.day}</div>
                <h3 className="font-bold mb-1">{day.title}</h3>
                <p className="text-sm text-muted-foreground">{day.activities} activities</p>
              </div>
            </div>
          </GlassCard>
        ))}

        <div className="grid grid-cols-2 gap-3 pt-4">
          <Button variant="outline" size="lg" onClick={() => navigate('/map')}>
            View Map
          </Button>
          <Button variant="gradient" size="lg" onClick={() => navigate('/hotels')}>
            Book Hotels
          </Button>
        </div>
      </div>
    </div>
  );
}
