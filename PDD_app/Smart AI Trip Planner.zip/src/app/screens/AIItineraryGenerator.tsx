import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function AIItineraryGenerator() {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => navigate('/itinerary/1'), 500);
          return 100;
        }
        return prev + 10;
      });
    }, 300);

    return () => clearInterval(interval);
  }, [navigate]);

  return (
    <div className="h-screen w-full bg-gradient-to-br from-primary via-secondary to-accent flex items-center justify-center p-6">
      <div className="max-w-md w-full text-center">
        <motion.div
          animate={{ rotate: 360, scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-24 h-24 mx-auto mb-8 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center"
        >
          <Sparkles className="w-12 h-12 text-white" />
        </motion.div>

        <h1 className="text-white text-2xl font-bold mb-4">Creating Your Perfect Itinerary</h1>
        <p className="text-white/80 mb-8">
          AI is analyzing thousands of destinations, activities, and experiences...
        </p>

        <div className="w-full bg-white/20 backdrop-blur-sm rounded-full h-3 overflow-hidden mb-4">
          <motion.div
            className="h-full bg-white rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          ></motion.div>
        </div>

        <p className="text-white/60 text-sm">{progress}% Complete</p>
      </div>
    </div>
  );
}
