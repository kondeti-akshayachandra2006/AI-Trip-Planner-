import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Mic, Sparkles } from 'lucide-react';
import GlassCard from '../components/GlassCard';

const sampleMessages = [
  { id: 1, type: 'ai', text: 'Hi! I\'m your AI travel assistant. How can I help you plan your next adventure?' },
  { id: 2, type: 'user', text: 'I want to visit Japan for 10 days' },
  { id: 3, type: 'ai', text: 'Great choice! Japan is amazing. When are you planning to visit? This will help me create the perfect itinerary for you.' },
];

export default function AIChatAssistant() {
  const navigate = useNavigate();
  const [messages] = useState(sampleMessages);
  const [input, setInput] = useState('');

  return (
    <div className="h-screen w-full bg-background flex flex-col">
      <div className="bg-gradient-to-r from-primary to-secondary p-6 pb-8">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="text-white">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex-1">
            <h1 className="text-white font-bold">AI Travel Assistant</h1>
            <p className="text-white/80 text-sm">Powered by TripAI</p>
          </div>
          <button onClick={() => navigate('/ai-prompts')} className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {message.type === 'ai' && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mr-2 flex-shrink-0">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            )}
            <div
              className={`max-w-[80%] p-4 rounded-3xl ${
                message.type === 'user'
                  ? 'bg-gradient-to-r from-primary to-secondary text-white'
                  : 'bg-muted'
              }`}
            >
              <p className="text-sm">{message.text}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="p-6 border-t border-border">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
            <Mic className="w-5 h-5 text-foreground" />
          </button>
          <input
            type="text"
            placeholder="Ask me anything..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 px-4 py-3 bg-input-background border border-border rounded-full focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <button className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
            <Send className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
