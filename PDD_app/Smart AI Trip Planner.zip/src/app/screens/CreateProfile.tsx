import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, User, MapPin, Phone } from 'lucide-react';
import Button from '../components/Button';
import Input from '../components/Input';

export default function CreateProfile() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({
    name: '',
    location: '',
    phone: '',
  });

  const handleContinue = () => {
    navigate('/preferences');
  };

  return (
    <div className="min-h-screen w-full bg-background p-6 flex flex-col">
      <div className="flex-1 flex flex-col max-w-md mx-auto w-full">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Create Profile</h1>
          <p className="text-muted-foreground">Tell us a bit about yourself</p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
              <User className="w-16 h-16 text-white" />
            </div>
            <button className="absolute bottom-0 right-0 w-10 h-10 bg-accent text-white rounded-full flex items-center justify-center shadow-lg">
              <Camera className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="space-y-4 mb-auto">
          <Input
            placeholder="Full Name"
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            icon={<User className="w-5 h-5" />}
          />

          <Input
            placeholder="Location"
            value={profile.location}
            onChange={(e) => setProfile({ ...profile, location: e.target.value })}
            icon={<MapPin className="w-5 h-5" />}
          />

          <Input
            type="tel"
            placeholder="Phone Number"
            value={profile.phone}
            onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
            icon={<Phone className="w-5 h-5" />}
          />
        </div>

        <Button variant="gradient" size="lg" className="w-full mt-8" onClick={handleContinue}>
          Continue
        </Button>
      </div>
    </div>
  );
}
